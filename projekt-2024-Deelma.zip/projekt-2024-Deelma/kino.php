<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maslekino</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Maslekino</h1>
    </header>
    <nav>
        
    </nav>
</body>
</html>

<?php










?>